
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
	Login l = null;
	LoginDAO log = new LoginDAO();

	// Write the code for adding and deleting Login data
	@Test
	public void Test() {
		assertFalse(log.addLogin(l));
	}
	@Test
	public void Test1() {
		assertFalse(log.deleteLogin(l));
	}
	@Test
	public void Test2() {
		l = new Login("root","root");
		assertTrue(log.addLogin(l));
	}
	@Test
	public void Test3() {
		l = new Login("root","root");
		assertFalse(log.deleteLogin(l));
	}
}
