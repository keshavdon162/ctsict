import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;

public class ProductTest {

	Product p = null;
	ProductDAO po = new ProductDAO();

	// Write the code for adding and deleting Login data
	@Test
	public void Test() {
		assertFalse(po.addProduct(p));
	}
	// Write the code for test methods
	@Test
	public void Test1() {
		assertFalse(po.deleteProduct(p));
	}
	@Test
	public void Test2() {
		p = new Product();
		assertFalse(po.deleteProduct(p));
	}
	@Test
	public void Test3() {
		p = new Product();
		assertTrue(po.addProduct(p));
	}
	@Test
	public void Test4() {
		p = new Product("123", "annaga", 1.0);
		assertTrue(po.addProduct(p));
	}
	@Test
	public void Test5() {
		p = new Product("123", "annaga", 1.0);
		assertFalse(po.deleteProduct(p));
	}
	@Test
	public void Test6() {
		p = new Product();
		p.setPrice(12);
		p.setProductId("122");
		p.setProductName("naga");
		po.addProduct(p);
		assertTrue(po.deleteProduct(p));
	}
}
