import static org.junit.Assert.assertEquals;
import java.util.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

public class EMICalculatorTest {
	EMICalculator emi = new EMICalculator();
//Write JUNIT Test Code

        @Test
		public void Test() {
			assertEquals(556.58,emi.calculateEMI(20000, "Housing Loan", 3),0.01);
			
		}
		@Test
		public void Test1() {
			assertEquals(556.49,emi.calculateEMI(20000, "Vehicle Loan", 3),0.01);
			
		}
		@Test
		public void Test2() {
			assertEquals(556.41,emi.calculateEMI(20000, "Personal Loan", 3),0.01);
			
		}
		@Test
		public void Test3(){
		    assertEquals(0.0,emi.calculateEMI(1000, "Personal Loan", 3),0.01);
		}
		
}
