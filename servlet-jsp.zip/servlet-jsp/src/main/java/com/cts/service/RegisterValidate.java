package com.cts.service;

public class RegisterValidate {
public boolean validate(Register r) {
	if(r.getPassword=)
}
}
