package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.barath.interfaces.DiscountServiceImpl;
import com.barath.model.Product;

@Controller
public class DiscountController {

	@Autowired
	DiscountServiceImpl service;
	
	@RequestMapping(value = "/getDiscountedPrice",method = RequestMethod.GET)
	public String discountPage(@ModelAttribute Product product) {
		return "calculatediscount";
	}
	
	@RequestMapping(value = "/calculateDiscountedPrice",method = RequestMethod.POST)
	public String calculateDiscount(@Valid @ModelAttribute Product product,ModelMap model,
			BindingResult result) {
		if(result.hasErrors())
			return "calculatediscount";
		double discountPrice = service.calculateDiscount(product);
		System.out.println(discountPrice);
		model.addAttribute("discountedAmount", discountPrice);
		return "finalprice";
	}
	
	@ModelAttribute("productTypeList")
	public List<String> populateProductType() {
		List<String> productType=new ArrayList<String>();
		productType.add("Electronics");
		productType.add("Toys");
		productType.add("Apparels");
		return productType;
	}
}
