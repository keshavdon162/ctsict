package com.barath.interfaces;

import org.springframework.stereotype.Service;

import com.barath.model.Product;

@Service
public class DiscountServiceImpl implements DiscountService {

	@Override
	public double calculateDiscount(Product product) {
		String productType=product.getProductType();
		double discountPercentage=0.0;
		double productPrice=product.getProductPrice();
		if(productType.equalsIgnoreCase("Electronics"))
			discountPercentage=25;

		else if(productType.equalsIgnoreCase("Apparels"))
			discountPercentage=10;

		else if(productType.equalsIgnoreCase("Toys"))
			discountPercentage=15;
		return productPrice-(productPrice*(discountPercentage/100.0));
//		Discounted Price = Product Price -( Product Price *(Discount percentage /100))
	}

}
