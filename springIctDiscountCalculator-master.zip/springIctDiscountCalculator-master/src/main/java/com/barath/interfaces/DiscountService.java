package com.barath.interfaces;

import com.barath.model.Product;


public interface DiscountService {
	public double calculateDiscount(Product product);

}
