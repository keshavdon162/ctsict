package com.barath.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class Product {

	public Product() {
		super();
	}

	private String productType;
	
	@Min(value = 0, message = "Price cannot be empty")
	private double productPrice;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
}
