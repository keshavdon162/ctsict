package com.cts.employee.service;

import org.springframework.stereotype.Service;
import com.cts.employee.model.Emp;

@Service
public class LoginService {
	public boolean validate(Emp emp) {

		return true;
		}


}
