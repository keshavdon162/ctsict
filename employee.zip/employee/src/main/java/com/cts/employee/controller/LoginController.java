package com.cts.employee.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.employee.model.Emp;
import com.cts.employee.service.LoginService;

@Controller
public class LoginController {
	@Autowired
	private LoginService service;

	    @RequestMapping(value="/login", method=RequestMethod.GET)
	public String showLoginpage(@ModelAttribute("register") Emp emp) {
	   
	return "login";

	}


	@RequestMapping(value="/submitlogin", method=RequestMethod.POST)
	public String checkLoginDetails(@Valid@ModelAttribute("register") Emp emp,BindingResult result) {

	  if(result.hasErrors())
	  {
		  return "login";
		 
	  } else if(service.validate(emp))
		    
	       return "success";
	  else
		  return "login";
		 	 

	}
}
