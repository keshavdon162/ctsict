package com.service;

import org.springframework.stereotype.Service;

import com.model.UserClaim;

//Implementing TaxService interface
@Service
public class TaxServiceImpl implements TaxService {

	//Checking Expense type and expense amount 
	//and setting taxClaimAmount accordingly
	@Override
	public double calculateTax(UserClaim userClaim) {
		double taxClaimAmount = userClaim.getExpenseAmt();
		if (userClaim.getExpenseType().equals("MedicalExpense")) {
			if (taxClaimAmount <= 1000) {
				taxClaimAmount = taxClaimAmount * (0.15);
			} else if (taxClaimAmount > 1000 && taxClaimAmount <= 10000) {
				taxClaimAmount = taxClaimAmount * (0.2);
			} else {
				taxClaimAmount = taxClaimAmount * (0.25);
			}
		} else if (userClaim.getExpenseType().equals("TravelExpense")) {
			if (taxClaimAmount <= 1000) {
				taxClaimAmount = taxClaimAmount * (0.1);
			} else if (taxClaimAmount > 1000 && taxClaimAmount <= 10000) {
				taxClaimAmount = taxClaimAmount * (0.15);
			} else {
				taxClaimAmount = taxClaimAmount * (0.2);
			}
		} else if (userClaim.getExpenseType().equals("FoodExpense")) {
			if (taxClaimAmount <= 1000) {
				taxClaimAmount = taxClaimAmount * (0.5);
			} else if (taxClaimAmount > 1000 && taxClaimAmount <= 10000) {
				taxClaimAmount = taxClaimAmount * (0.1);
			} else {
				taxClaimAmount = taxClaimAmount * (0.15);
			}
		}
		return taxClaimAmount;
	}
}
