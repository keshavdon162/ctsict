package com.service;

import org.springframework.stereotype.Service;

import com.model.UserClaim;

//Creating an Interface for tax Service functions
@Service
public interface TaxService {

	public double calculateTax(UserClaim userClaim);

}
