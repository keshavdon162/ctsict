package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.UserClaim;
import com.service.TaxService;

@Controller
@ComponentScan({ "com.service", "com.model"})
@Qualifier("TaxServiceImpl")
public class TaxController {
	//AutoWiring local variable to TaxService
	@Autowired
	private TaxService taxService;
	
	//Mapping the flow to taxclaim page
	@RequestMapping(value="/getTaxClaimFormPage", method=RequestMethod.GET)
	public String claimPage(@ModelAttribute("userClaim") UserClaim userClaim) {
		return "taxclaim";
	}
	
	//Mapping the flow to result page if it has no errors
	@RequestMapping(value = "/calculateTax", method=RequestMethod.GET)
	public String calculateTax(@ModelAttribute("userClaim") @Valid UserClaim userClaim, BindingResult result, ModelMap map) {
		//Checking for errors
		if(result.hasErrors()) {
			//if any errors flow goes back to home page(taxclaim)
			return "taxclaim";
		}
		//adding attribute to the model map
		map.addAttribute("taxClaimAmount", taxService.calculateTax(userClaim));
		return "result";
	}
	
	//Creating a model attribute for List
	//to be called in result.jsp
	@ModelAttribute("expenseList")
	public List<String> populateExpense(){
		//New array list is created
		List<String> li = new ArrayList<>();
		//Attributes are added
		li.add("MedicalExpense");
		li.add("TravelExpense");
		li.add("FoodExpense");
		return li;
	}
}
