package com.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

//Declaring it as a component
@Component
public class UserClaim {

	private String expenseType;
	//Checking for negative values in expense amount
	@Range(min = 0, message = "{error.expenseAmount.negative}")
	private double expenseAmt;
	
	//Checking if the String is empty
	@NotEmpty(message = "{error.employeeId}")
	//Checking if the String is of length 5
	@Size(min = 5, message = "{error.employeeId.format}")
	private String employeeId;

	//Getter for expense type
	public String getExpenseType() {
		return expenseType;
	}

	//Setter for expense type
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}

	//getter for expense amount
	public double getExpenseAmt() {
		return expenseAmt;
	}

	//Setter for expense amount
	public void setExpenseAmt(double expenseAmt) {
		this.expenseAmt = expenseAmt;
	}
	
	//getter for Employee Id
	public String getEmployeeId() {
		return employeeId;
	}
	
	//Setter for Employee Id
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
}
