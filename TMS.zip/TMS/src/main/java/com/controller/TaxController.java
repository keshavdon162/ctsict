package com.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.UserClaim;
import com.service.TaxService;
import com.service.TaxServiceImpl;

@Controller
public class TaxController {
	
	@Autowired
	private TaxService taxService; //inerface is autowired through annotations
	
	@RequestMapping(value="/getTaxClaimFormPage")
	public String claimPage(@ModelAttribute("userClaim") UserClaim userClaim) {
		return "taxclaim";
	}
	
	@RequestMapping(value="/calculateTax",method=RequestMethod.GET)
	public String calculateTax(@Valid @ModelAttribute("userClaim") UserClaim userClaim, BindingResult result,
			ModelMap model) {
		if(result.hasErrors())//if error redirect to same page
		return "taxclaim";
		double calculateTax = taxService.calculateTax(userClaim);
		model.addAttribute("taxClaimAmount", calculateTax);
		model.addAttribute("expenseType", userClaim.getExpenseType());
		model.addAttribute("expenseAmount", userClaim.getExpenseAmt());
		return "result";
	}
	
	@ModelAttribute("expenseList")
	public List<String> populateExpense() {
		//adding to the dynamic drop down list box
		List<String> list=new ArrayList<String>();
		list.add("MedicalExpense");
		list.add("TravelExpense");
		list.add("FoodExpense");
		return list;
	}

}
