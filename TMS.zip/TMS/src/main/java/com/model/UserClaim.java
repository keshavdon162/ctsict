package com.model;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class UserClaim {
	
	private String expenseType;
	
	
	@Min(value = 0, message = "{error.expenseAmount.negative}")
	private double expenseAmt;//Expense Amount should not be a negative number.
	@NotBlank(message="{error.employeeId}")
	@Size(min = 5, max = 200, message  = "{error.employeeId.five}")
	private String employeeId;//Employee ID field is mandatory. : Employee ID should be at least 5 characters
	
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public double getExpenseAmt() {
		return expenseAmt;
	}
	public void setExpenseAmt(double expenseAmt) {
		this.expenseAmt = expenseAmt;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	
	
}
