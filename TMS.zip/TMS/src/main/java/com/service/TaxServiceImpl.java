package com.service;

import org.springframework.stereotype.Service;

import com.model.UserClaim;

@Service
public class TaxServiceImpl implements TaxService{

	@Override
	public double calculateTax(UserClaim userClaim) {
		// TODO Auto-generated method stub
		String serviceType=userClaim.getExpenseType();
		double expenseAmount=userClaim.getExpenseAmt();
		int taxPercentage=0;
		if(serviceType.equals("MedicalExpense"))
		{
			if(expenseAmount<=1000)
				taxPercentage=15;
			else if(expenseAmount>=1001&&expenseAmount<=10000)
				taxPercentage=20;
			else if(expenseAmount>10000)
				taxPercentage=25;
		}
		else if(serviceType.equals("TravelExpense"))
		{
			if(expenseAmount<=1000)
				taxPercentage=10;
			else if(expenseAmount>=1001&&expenseAmount<=10000)
				taxPercentage=15;
			else if(expenseAmount>10000)
				taxPercentage=20;
		}
		else if(serviceType.equals("FoodExpense")) {
			if(expenseAmount<=1000)
				taxPercentage=5;
			else if(expenseAmount>=1001&&expenseAmount<=10000)
				taxPercentage=10;
			else if(expenseAmount>10000)
				taxPercentage=15;
		}
		return expenseAmount*(taxPercentage/100.0);
//		Expense amount * (Tax percentage /100)
	}

}
