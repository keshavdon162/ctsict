
import org.junit.Test;
import static org.junit.Assert.*;
public class CustomerTest {
	//Write the code for testing assertion using JUNIT
      Customer c = null;
    
    @Test 
    public void Test(){
        c = new Customer("2123456789123456","jack","daniels","27,appasamy",909,"nagarjun@gmail.com");
        assertNotSame(c.getFirstName(),c.getLastName());
        assertNotNull(c.getEmailId());
    }
}
