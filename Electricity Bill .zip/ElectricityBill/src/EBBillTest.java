import static org.junit.Assert.assertTrue;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.rules.TestName;
public class EBBillTest
{
    
EBBill eb = null;
    
    @Test
    public void Test1(){
       eb = new EBBill(10);
       assertTrue(eb.calculateBillAmount()>0);
       
    }
    
    
    @Test
    public void Test2(){
          eb = new EBBill(0);
          assertEquals(0, eb.calculateBillAmount(),0.001);
     }
     @Test
    public void Test3(){
         eb = new EBBill(75);
       assertTrue(eb.calculateBillAmount()>0);
     }
     @Test
    public void Test4(){
         eb = new EBBill(150);
       assertTrue(eb.calculateBillAmount()>0);
     }
     @Test
    public void Test5(){
         eb = new EBBill(500);
       assertTrue(eb.calculateBillAmount()>0);
     }
      @Test
    public void Test6(){
         eb = new EBBill(2500);
       assertTrue(eb.calculateBillAmount()>0);
     }    
}