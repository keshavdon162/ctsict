package com.service;

import org.springframework.stereotype.Service;

import com.model.HelperBean;

//use appropriate annotation to configure HelperService as a Service
@Service
public class HelperService {
	
	
	//calculate the totalCost and return the cost
	public double calculateTotalCost(HelperBean helperBean)
	{
		String serviceType=helperBean.getServiceType();
		double totalCost = 0;
		if(serviceType.equals("ACService"))
			totalCost=helperBean.getNoOfHours()*400;
		 else if(serviceType.equals("WashingMachineService"))
			 totalCost=helperBean.getNoOfHours()*500;
		 else if(serviceType.equals("RefrigeratorService"))
			 totalCost=helperBean.getNoOfHours()*300;
	
		 return totalCost;
		
		
	}

}
	 	  	    	    	     	      	 	
